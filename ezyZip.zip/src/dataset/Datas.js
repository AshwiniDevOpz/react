// File: cart/src/Dataset/Data.jsx
export  const Data = [
    { name: 'Apple',age: 20 },
    { name: 'Banana', age: 25 },
    { name: 'Orange', age: 30 },
  ];
  